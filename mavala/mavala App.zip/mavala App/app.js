//here we imporet the express first.
const express = require('express');

//here we create app from express 
const app = express();

//we need mongoose here to connect the data base 
const mongoose = require('mongoose');

const bodyParser = require('body-parser');
// here require the dotenv for database connection in short her we get the db url of mongo atlase.
require('dotenv/config');
//here we require body-parser.
app.use(bodyParser.json())
//here we get the rout file to route in app as per the api call
const routing = require('./routes/routes');
app.use('',routing);

//here we connect the mongo data base by using mongoose.
mongoose.connect(
    process.env.DB_CONNECTION,
    { useUnifiedTopology: true, useNewUrlParser: true },
    () => {
        console.log("connected to DB");
    }
)

//here the set port to over app to listen 
app.listen(1992);
