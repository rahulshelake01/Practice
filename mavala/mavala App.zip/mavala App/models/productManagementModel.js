//here we get the fort managemnet instance.
const fortManagementInstance = require('./_dbSchema/fortManagementSchema');



async function productList(reqBody, callBack) {
    fortManagementInstance.find({}, { "productName": 1, "productType": 1, "productType": 1, "prices": 1,}).then((result) => {
        return callBack(null, { status: 200, fortList: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function productDetails(reqBody, callBack) {
    console.log(reqBody);
    fortManagementInstance.findOne({ _id: reqBody._id }, { "productName": 1, "productType": 1, "prices": 1, "productSize": 1, "productDetails": 1, "productSizeFit": 1, "productMaterialCare":1,"productStyleNote":1,"productImages":1,"productRating":1,}).then((result) => {
        return callBack(null, { status: 200, fortDetail: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}



module.exports = { productList, productDetails }