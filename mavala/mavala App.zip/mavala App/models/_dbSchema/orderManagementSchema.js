//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const orderMasterSchema = new mongoose.Schema({

    bookName:String,
    bookType:String,
    prices:String,
    bookDetails:String,
  

});
//here we create an instace userManagement schema 
const orderMasterInstance = mongoose.model("product_masters",orderMasterSchema);
module.exports = orderMasterInstance;