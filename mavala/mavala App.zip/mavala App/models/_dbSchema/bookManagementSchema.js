//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const bookMasterSchema = new mongoose.Schema({

    bookName:String,
    bookType:String,
    prices:String,
    bookDetails:String,
    bookImages:[{type:String}],
    bookRating:[{
        postPersonId:String,
        postPersonName:String,
        userName:String,
        description:String,
        dataTime:Date,
        bookImages:[{type:String}],
    }],

});
//here we create an instace userManagement schema 
const bookMasterInstance = mongoose.model("product_masters",bookMasterSchema);
module.exports = bookMasterInstance;