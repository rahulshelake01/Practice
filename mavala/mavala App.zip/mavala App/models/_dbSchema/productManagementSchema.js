//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const productMasterSchema = new mongoose.Schema({

    productName:String,
    productType:String,
    prices:String,
    productSize:String,
    productDetails:String,
    productSizeFit:String,
    productMaterialCare:String,
    productStyleNote:String,
    productImages:[{type:String}],
    productRating:[{
        postPersonId:String,
        postPersonName:String,
        userName:String,
        description:String,
        dataTime:Date,
        productImages:[{type:String}],
    }],

});
//here we create an instace userManagement schema 
const productMasterInstance = mongoose.model("product_masters",productMasterSchema);
module.exports = productMasterInstance;