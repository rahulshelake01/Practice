//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const productCategoriesMasterSchema = new mongoose.Schema({

    categoriesName:String,
    type:String,
    categoriesIamgeUrl:String,
   

});
//here we create an instace userManagement schema 
const productCategoriesMasterInstance = mongoose.model("productCategories_masters",productCategoriesMasterSchema);
module.exports = productCategoriesMasterInstance;