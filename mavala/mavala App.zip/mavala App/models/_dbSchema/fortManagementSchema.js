//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const fortManagementSchema = new mongoose.Schema({

    fortName:String,
    fortDistrict:String,
    latitude:String,
    longitude:String,
    fortDiscription:String,
    fortImages:[{type:String}],
    visitedPersons:[{
        postPersonId:String,
        postPersonName:String,
        visitorName:String,
        visitorMobileNo:String,
        dataTime:Date
    }],
    issues:[{
        issueDate:Date,
        issueSubmitedBy:String,
        issueSubject:String,
        issueDiscription:String
    }], 
    

});
//here we create an instace userManagement schema 
const fortManagementInstance = mongoose.model("fort_masters",fortManagementSchema);
module.exports = fortManagementInstance;