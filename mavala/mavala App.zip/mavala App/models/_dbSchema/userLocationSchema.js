//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const userLocationSchema = new mongoose.Schema({
   

    userid:String,
    latitude:String,
    longitude:String,

});
//here we create an instace userManagement schema 
const userLocationInstance = mongoose.model("user_location",userLocationSchema);
module.exports = userLocationInstance;