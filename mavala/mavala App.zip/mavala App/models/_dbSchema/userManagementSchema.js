//here we need mongoose for database schema.
const  mongoose  = require("mongoose");
//here we create userManagemnt schema.
const userMasterSchema = new mongoose.Schema({

    userName:String,
    mobileNo:String,
    address:String,
    email:String,
    otp:String,
    verifide:Boolean

});
//here we create an instace userManagement schema 
const userMasterInstance = mongoose.model("user_masters",userMasterSchema);
module.exports = userMasterInstance;