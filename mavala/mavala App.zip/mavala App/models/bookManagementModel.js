//here we get the fort managemnet instance.
const bookManagementInstance = require('./_dbSchema/bookManagementSchema');



async function bookList(reqBody, callBack) {
    bookManagementInstance.find({}, { "bookName": 1, "bookType": 1, "prices": 1, "bookDetails": 1, "bookImages": 1, }).then((result) => {
        return callBack(null, { status: 200, fortList: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function bookDetails(reqBody, callBack) {
    console.log(reqBody);
    bookManagementInstance.findOne({ _id: reqBody._id }, { "bookName": 1, "bookType": 1, "prices": 1, "bookDetails": 1, "bookImages": 1, }).then((result) => {
        return callBack(null, { status: 200, fortDetail: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function bookRatingList(reqBody, callBack) {
    bookManagementInstance.find({ _id: reqBody._id }, { "postPersonName": 1, "userName": 1,"description": 1, "dataTime": 1,}, (error, result) => {

        if (error) {
            return callBack(null, { status: 500, massage: error });
        }
        return callBack(null, { status: 200, visitorList: result });
    })
}


module.exports = { bookDetails, bookList, bookRatingList, }