//here we get the fort managemnet instance.
const productCategoriesManagementInstance = require('./_dbSchema/productCategoriesManagementSchema');



async function productCategoriesList(reqBody, callBack) {
    productCategoriesManagementInstance.find({}, { "categoriesName": 1, "type": 1, "categoriesIamgeUrl": 1,}).then((result) => {
        return callBack(null, { status: 200, fortList: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function productCategoriesDetails(reqBody, callBack) {
    console.log(reqBody);
    productCategoriesManagementInstance.findOne({ _id: reqBody._id }, { "categoriesName": 1, "type": 1, "categoriesIamgeUrl": 1,}).then((result) => {
        return callBack(null, { status: 200, fortDetail: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}



module.exports = { productCategoriesList, productCategoriesDetails }