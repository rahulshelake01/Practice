const { getOTP } = require('../utils/utils');
//now here we get instance of userMasterInstance to do opertaion on db.
const userMasterInstance = require('./_dbSchema/userManagementSchema');
//here we get and user location instance .
const userLocationInstance = require('./_dbSchema/userLocationSchema'); 

//here the function which work with databace 
//here is the signin function to check user is sign in 
async function signIn(reqBody, callBack) {
   //here we first check that the user mobile is exists in db 
   userMasterInstance.findOne({ mobileNo: reqBody.mobileNo },
      (error, result) => {
         //if error found then send error call back.
         if (error) {
            return callBack(error, null);
         } else if (result == null) {
            //if user result is notfound then show user is exsis. 
            return callBack(null, { status: 400, message: "User Not exist." });
         }
         //we get the otp
         let otpNumber = getOTP();
         userMasterInstance.updateOne({ mobileNo: reqBody.mobileNo }, { $set: { otp: otpNumber } }, (error, res) => {
            if (error) {
               return callBack(error, null);
            }
            //other vise send user otp to user on there phone number.
            return callBack(null, { status: 200, message: "OTP send on your mobile no." });
         })

      }
   )
}
//this below function is use for uesr sign up.
async function signUp(reqBody, callBack) {

   userMasterInstance.findOne({ mobileNo: reqBody.mobileNo }, (error, userIsExists) => {
      //here we check that user is not exists the save the user data .
      if (userIsExists == null) {
         //here we set otp empty 
         reqBody.otp = "";
         //if user not exists then we create the user.
         userMasterInstance(reqBody).save((err, result) => {
            if (err) {
               return callBack(err, null);
            }
            return callBack(null, { status: 200, massage: "Registration done successfully" });
         })
      } else {
         //else return the user is already exists.
         return callBack(null, { status: 409, massage: "User already exists." });
      }
   });
}

async function verify(reqBody, callBack) {
   userMasterInstance.findOne({ mobileNo: reqBody.mobileNo, otp: reqBody.otp }, (error, result) => {

      if (result == null) {
         return callBack(null, { status: 403, massage: "Please check mobile no / otp." })
      }
      userMasterInstance.updateOne({ mobileNo: reqBody.mobileNo }, { $set: { verifide: true } }, (updateError, upDateResult) => {

         if (updateError) {
            return callBack(null, { status: 500, massage: updateError })
         }

         return callBack(null, { status: 200, message: "Mobile no is Verifyed successfully.", userProfile: result});
      });
   });
}

//here  we get store the user location by user id.
async function userLocation(reqBody,callBack){
   userLocationInstance(reqBody).save((error , result)=>{

      if(error){
         return callBack(null, { status: 500, massage: error })
      }
      return callBack(null,{status:200, message:'user Location store successfully.'})
   });
}

module.exports = { signIn, signUp, verify ,userLocation}