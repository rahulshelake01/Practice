//here we get the fort managemnet instance.
const fortManagementInstance = require('./_dbSchema/fortManagementSchema');



async function fortList(reqBody, callBack) {
    fortManagementInstance.find({}, { "fortName": 1, "fortDistrict": 1, "fortImages": 1, "latitude": 1, "longitude": 1, "fortDiscription": 1, }).skip((reqBody.page - 1) * 10).limit(reqBody.limit).then((result) => {
        return callBack(null, { status: 200, fortList: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function fortDetails(reqBody, callBack) {
    console.log(reqBody);
    fortManagementInstance.findOne({ _id: reqBody._id }, { "fortName": 1, "fortImages": 1, "fortDistrict": 1, "latitude": 1, "longitude": 1, "fortDiscription": 1, }).then((result) => {
        return callBack(null, { status: 200, fortDetail: result });
    }).catch((error) => {
        return callBack(null, { status: 409, message: error });
    });
}

async function fortVisitorList(reqBody, callBack) {
    fortManagementInstance.find({ _id: reqBody._id }, { "visitedPersons": 1 }, (error, result) => {

        if (error) {
            return callBack(null, { status: 500, massage: error });
        }
        return callBack(null, { status: 200, visitorList: result });
    })
}
async function fortIssuesList(reqBody, callBack) {
    fortManagementInstance.find({ _id: reqBody._id }, { "issues": 1 }, (error, result) => {

        if (error) {
            return callBack(null, { status: 500, massage: error });
        }
        return callBack(null, { status: 200, issuesList: result });
    })
}

module.exports = { fortList, fortDetails, fortVisitorList,fortIssuesList }