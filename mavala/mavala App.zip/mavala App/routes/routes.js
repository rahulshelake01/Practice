//here we need the express 
const express = require("express");
//all controller is call here below.
const user  = require("../controllers/userManagement/userManagmentController");
const fort = require("../controllers/fortManagement/fortManagementController");
const book = require("../controllers/bookManagement/bookManagementController");
const order = require("../controllers/orderManagement/orderManagementController");
const product = require("../controllers/productManagement/productManagaementController");
const productCategories = require("../controllers/productCategoriesManagement/productCategoriesManagementController");


//here we create the router for access the route.
const router = express.Router();

//user managment route is here.
router.use('/userManagment',user);
//fort managment rout is here.
router.use('/fortManagement',fort);
//book management rout is here
router.use('/bookManagement'.book);
//order Managemenrt rout is here
router.use('/orderManagement',order);
//product management router is here 
router.use('/productManagemet'.product);
//product Categories Mangemet router is here
router.use('/productCategoriesManagement',productCategories);
app.use(app.router);
routes.initialize(app);


module.exports = router;