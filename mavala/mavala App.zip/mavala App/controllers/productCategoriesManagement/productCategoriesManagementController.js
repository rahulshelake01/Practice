//here we need the express 
const express = require('express');
//here we need the router 
const router = express.Router();
//here we get the fort model file.
const productCategoriesManagementModel = require('../../models/productCategoriesManagementModel');


router.get('/productCategoriesList',(req,res)=>{
    productCategoriesManagementModel.productCategoriesList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/productCategoriesDetails',(req,res)=>{
    productCategoriesManagementModel.productCategoriesDetails(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

module.exports= router;