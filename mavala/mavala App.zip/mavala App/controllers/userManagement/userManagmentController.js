//here we need the express 
const express = require('express');
//here we need the router 
const router = express.Router();
//also we need here the modal instance.
const userManagementModel = require("../../models/userManagementModel");

//here is the signup controller 
router.post('/signup',(req,res,next)=>{
    userManagementModel.signUp(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
});


//here is the signin controller 
router.post('/signin',(req,res,next)=>{
    userManagementModel.signIn(req.body,(error,result)=>{
        console.log(`constroller error===>${error}  result===>${result}`)
        if(error){
            return res.status(500).json({message:error});
        }else if(result.message=="User Not exist."){
            res.status(404).json(result);
        }else{
            res.status(200).json(result);
        }
    })
});

//
router.post('/verify',(req,res,next)=>{
    userManagementModel.verify(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    });
});

router.post('/userLocation',(req,res,next)=>{
    userManagementModel.userLocation(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    });
});

module.exports = router;