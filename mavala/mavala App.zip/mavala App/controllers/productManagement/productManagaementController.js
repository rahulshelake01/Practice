//here we need the express 
const express = require('express');
//here we need the router 
const router = express.Router();
//here we get the fort model file.
const fortManagementModel = require('../../models/fortManagamentModel');


router.get('/productList',(req,res)=>{
    productManagementModel.productList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/productDetails',(req,res)=>{
    productManagementModel.productDetails(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

module.exports= router;