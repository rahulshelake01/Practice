//here we need the express 
const express = require('express');
//here we need the router 
const router = express.Router();
//here we get the fort model file.
const fortManagementModel = require('../../models/fortManagamentModel');


router.get('/fortList',(req,res)=>{
    fortManagementModel.fortList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/fortDetails',(req,res)=>{
    fortManagementModel.fortDetails(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/fortVisitorList',(req,res)=>{
    fortManagementModel.fortVisitorList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})
router.post('/fortIssuesList',(req,res)=>{
    fortManagementModel.fortIssuesList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})
module.exports= router;