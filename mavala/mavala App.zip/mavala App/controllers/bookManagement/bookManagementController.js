//here we need the express 
const express = require('express');
//here we need the router 
const router = express.Router();
//here we get the fort model file.
const bookManagementModel = require('../../models/bookManagementModel');


router.get('/bookList',(req,res)=>{
    bookManagementModel.bookList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/bookDetails',(req,res)=>{
    bookManagementModel.bookDetails(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

router.post('/bookRatingList',(req,res)=>{
    bookManagementModel.bookRatingList(req.body,(error,result)=>{
        if(error){
            res.status(500).json({message:error});
        }
        res.status(200).json(result);
    })
})

module.exports= router;