

//this below function is create the 4 digit random number 

function getOTP() {
    let otp =  Math.floor(1000 + Math.random() * 9000);
    console.log(otp);
    return otp;
}

module.exports = { getOTP };